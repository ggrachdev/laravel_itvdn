<?php $__env->startSection('title'); ?> Thanks for your order <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <blockquote class="blockquote bq-success">
            <p class="bq-title">Thanks for your order!</p>
            <p>Hey, <?php echo e($order->user->name); ?>!</p>

            <p>Your order <strong>#<?php echo e($order->id); ?></strong> was successfully created. We will call you as soon as possible!</p>
        </blockquote>

        <div class="row">
            <div class="col">
                <a href="<?php echo e(route('index')); ?>" class="btn btn-success">Get back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>