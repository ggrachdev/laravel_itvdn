<!--Footer-->
<footer class="page-footer text-center font-small mt-4 wow fadeIn">
    <!--Copyright-->
    <div class="footer-copyright py-3">
        © 2018 Copyright:
        <a href="<?php echo e(route('index')); ?>"> <?php echo e(config('app.name')); ?> </a>
    </div>
    <!--/.Copyright-->
</footer>
<!--/.Footer-->
