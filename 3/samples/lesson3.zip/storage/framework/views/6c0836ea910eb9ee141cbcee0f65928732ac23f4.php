

<?php $__env->startSection('title'); ?> Cart <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container wow fadeIn">
        <h2 class="my-5 h2 text-center">Your cart</h2>

        <?php if(Cart::totalItems() > 0): ?>
            <table class="table table-striped">
                <thead class="black white-text">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product</th>
                    <th scope="col">Quantity</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <?php $i = 0; ?>
                <?php $__currentLoopData = Cart::contents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++; ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('cart.update')); ?>" method="post">
                                <?php echo method_field('patch'); ?>

                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="productId" value="<?php echo e($item->identifier); ?>">
                                <input type="number" name="qty" value="<?php echo e($item->quantity); ?>" min="1">
                                <button class="btn btn-sm btn-primary" type="submit">Update</button>
                            </form>
                        </td>
                        <td>
                            <a href="<?php echo e(route('cart.drop', ['productId' => $item->identifier])); ?>" type="button"
                               class="btn btn-danger" title="Delete"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="3">Total:</td>
                    <td><strong>&dollar;<?php echo e(Cart::total()); ?></strong></td>
                </tr>
                </tfoot>
            </table>
            <a href="<?php echo e(route('cart.destroy')); ?>" class="btn-danger btn btn-lg">Clear cart</a>
            <a href="<?php echo e(route('cart.checkout')); ?>" class="btn-success btn btn-lg">
                Checkout <i class="fa fa-arrow-right"></i>
            </a>
        <?php else: ?>
            <blockquote class="blockquote bq-warning">
                <p class="bq-title">Do you like our products?</p>
                <p>Your cart is empty now. You can choose product in our <a href="<?php echo e(url('product')); ?>">catalog</a> and
                    enjoy them!
                </p>
            </blockquote>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>