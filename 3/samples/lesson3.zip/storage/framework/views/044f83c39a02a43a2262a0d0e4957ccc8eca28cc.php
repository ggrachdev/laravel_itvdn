<?php $__env->startSection('title'); ?> Checkout <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container wow fadeIn">

        <!-- Heading -->
        <h2 class="my-5 h2 text-center">Checkout</h2>

        <!--Grid row-->
        <div class="row">
            <!--Grid column-->
            <div class="col-md-8 mb-4">
                <!--Card-->
                <div class="card">
                    <!--Card content-->
                    <form class="card-body" action="<?php echo e(route('cart.order')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>


                    <!--Grid row-->
                        <div class="row">
                            <!--Grid column-->
                            <div class="col-md-6 mb-2">
                                <!--firstName-->
                                <div class="form-group">
                                    <label for="firstName" class="">First name</label>
                                    <input type="text" id="firstName" class="form-control" name="customerName"
                                           value="<?php echo e(auth()->user()->name); ?>">
                                </div>
                            </div>
                            <!--Grid column-->

                            <!--Grid column-->
                            <div class="col-md-6 mb-2">
                                <!--lastName-->
                                <div class="form-group">
                                    <label for="lastName" class="">Last name</label>
                                    <input type="text" id="lastName" class="form-control" name="customerLastName"
                                           value="<?php echo e(auth()->user()->lastname); ?>">
                                </div>

                            </div>
                            <!--Grid column-->

                        </div>
                        <!--Grid row-->

                        <!--email-->
                        <div class="form-group mb-5">
                            <label for="email" class="">Email</label>
                            <input type="text" id="email" class="form-control" placeholder="youremail@example.com"
                                   name="customerEmail" value="<?php echo e(auth()->user()->email); ?>" required>
                        </div>

                        <!--address-->
                        <div class="form-group mb-5">
                            <label for="phone" class="">Phone number</label>
                            <input type="text" id="phone" class="form-control" placeholder="+1 (123) 456-7890"
                                   name="customerPhone" value="<?php echo e(auth()->user()->phone); ?>">
                        </div>

                        <div class="form-group mb-5">
                            <label for="address" class="">Address</label>
                            <input type="text" id="address" class="form-control"
                                   placeholder="Park av., 123, New York, USA"
                                   name="customerAddress" value="<?php echo e(auth()->user()->address); ?>">
                        </div>

                        <div class="form-group mb-5">
                            <label for="comment" class="">Comment</label>
                            <textarea type="text" id="comment" class="form-control"
                                   placeholder="Comment"
                                   name="customerAddress"></textarea>
                        </div>

                        <hr class="mb-4">

                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="save-info" name="updateUser">
                            <label class="custom-control-label" for="save-info">Save this information for next
                                time</label>
                        </div>
                        <hr class="mb-4">
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Order it</button>

                    </form>

                </div>
                <!--/.Card-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-4 mb-4">
                <!-- Heading -->
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Your cart</span>
                    <span class="badge badge-secondary badge-pill"><?php echo e(Cart::totalItems(true)); ?></span>
                </h4>

                <!-- Cart -->
                <ul class="list-group mb-3 z-depth-1">
                    <?php $__currentLoopData = Cart::contents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0"><?php echo e($item->name); ?></h6>
                                <small class="text-muted">x <?php echo e($item->quantity); ?></small>
                            </div>
                            <span class="text-muted">&dollar;<?php echo e($item->price *  $item->quantity); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Total</span>
                        <strong>&dollar;<?php echo e(Cart::total()); ?></strong>
                    </li>
                </ul>
                <!-- Cart -->
                <a href="<?php echo e(route('cart.index')); ?>" class="btn-info btn btn-lg"><i class="fa fa-arrow-left"></i> Change
                    order</a>
            </div>
            <!--Grid column-->
        </div>
        <!--Grid row-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>