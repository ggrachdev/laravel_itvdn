

<?php $__env->startSection('title'); ?> <?php echo e($product->title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container dark-grey-text mt-5">

        <!--Grid row-->
        <div class="row wow fadeIn">
            <!--Grid column-->
            <div class="col-md-6 mb-4">
                <div class="row">
                    <div class="col-12">
                        <img src="<?php echo e($product->cover); ?>" class="img-fluid img-thumbnail"
                             alt="">
                    </div>
                </div>
                <div class="row mt-2">
                    <?php $__currentLoopData = $product->gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <img src="<?php echo e($photo); ?>" alt="" class="img-fluid img-thumbnail">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-6 mb-4">

                <!--Content-->
                <div class="p-4">

                    <div class="mb-3">
                        <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="">
                            <span class="badge
                             <?php if($category->id == 1): ?>
                                purple
                                <?php elseif($category->id == 2): ?>
                                blue
                                <?php elseif($category->id == 3): ?>
                                red
                                <?php elseif($category->id == 4): ?>
                                yellow
                                <?php elseif($category->id == 5): ?>
                                lime
                            <?php endif; ?>
                                mr-1"><?php echo e($category->name); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <p class="lead">
              <span class="mr-1">
              </span>
                        <span>$<?php echo e($product->price); ?></span>
                    </p>

                    <p class="lead font-weight-bold">Description</p>

                    <p>
                        <?php echo e($product->description); ?>

                    </p>

                    <?php if(session()->has('success')): ?>
                        <blockquote class="blockquote bq-success">
                            <p class="bq-title">Success!</p>
                            <p>Added to cart successfully. <a href="<?php echo e(route('cart.index')); ?>">Get cart?</a></p>
                        </blockquote>
                    <?php endif; ?>

                    <form class="d-flex justify-content-left"
                          action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <!-- Default input -->
                        <input type="number" name="quantity" value="1" aria-label="Search" class="form-control"
                               style="width: 100px" min="1">
                        <input type="hidden" name="productId" value="<?php echo e($product->id); ?>">
                        <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                            <i class="fa fa-shopping-cart ml-1"></i>
                        </button>
                    </form>
                </div>
                <!--Content-->

            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <hr>

        <!--Grid row-->
        <div class="row d-flex justify-content-center wow fadeIn">

            <!--Grid column-->
            <div class="col-md-6 text-center">

                <h4 class="my-4 h4">Additional information</h4>

                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus suscipit modi sapiente illo soluta
                    odit voluptates,
                    quibusdam officia. Neque quibusdam quas a quis porro? Molestias illo neque eum in laborum.</p>

            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <!--Grid row-->
        <div class="row wow fadeIn">

            <!--Grid column-->
            <div class="col-lg-4 col-md-12 mb-4">

                <img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Products/11.jpg" class="img-fluid"
                     alt="">

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4">

                <img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Products/12.jpg" class="img-fluid"
                     alt="">

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4">

                <img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Products/13.jpg" class="img-fluid"
                     alt="">

            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <hr>

        
        <?php if(auth()->guard()->guest()): ?>
            <blockquote class="blockquote bq-warning">
                <p class="bq-title">Sign in to comment</p>
                <p>Please <a href="<?php echo e(route('login')); ?>">sign in</a> to comment this product.</p>
            </blockquote>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
        <div class="row wow fadeIn">
            <div class="col-12">
                <form action="<?php echo e(route('comments.add')); ?>" class="form-group" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="productId" value="<?php echo e($product->id); ?>">
                    <div class="row">
                        <div class="col-12">
                            <textarea name="comment" id="comment" cols="30" rows="5" class="form-control"
                                      placeholder="Your comment here"></textarea>
                        </div>
                        <div class="col-12 mt-1">
                            <button type="submit" class="btn btn-primary btn-block">Leave Comment</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <div class="container mt-4">
            <div class="row">
                <div class="col-12">
                    <div class="panel panel-default widget">
                        <div class="panel-heading mb-4">
                            <span class="glyphicon glyphicon-comment"></span>
                            <h3>Recent Comments <span class="badge red"><?php echo e($product->comments->count()); ?></span></h3>
                        </div>
                        <div class="panel-body">
                            <ul class="list-group">
                                <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col-2 col-md-1">
                                                <img src="http://placehold.it/80" class="img-circle img-responsive" alt="" />
                                            </div>
                                            <div class="col-10 col-md-11">
                                                <div class="col-12">
                                                    <div class="mic-info">
                                                        By: <a href="#"><?php echo e($comment->user->name); ?> <?php echo e($comment->user->lastname); ?></a>
                                                        on <?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d M Y, H:i')); ?>

                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="comment-text">
                                                        <p >
                                                            <?php echo e($comment->comment); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>