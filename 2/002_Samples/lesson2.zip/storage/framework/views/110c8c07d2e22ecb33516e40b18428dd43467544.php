

<?php $__env->startSection('title'); ?> Catalog <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>&nbsp;</p>
    <div class="container-fluid">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('layouts.catalog.card', compact('product'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row align-content-center">
            <div class="container">
                <div class="col-4 offset-3">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>