<div class="col-3 mb-4 d-flex align-items-stretch">
    <div class="card">
        <img class="card-img-top" src="<?php echo e($product->cover); ?>" alt="<?php echo e($product->title); ?>">
        <div class="card-body">
            <h5 class="card-title">
                <a href="<?php echo e(route('catalog.show', ['slug' => $product->slug])); ?>">
                    <?php echo e($product->title); ?>

                </a>
            </h5>
            <p>
                <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="">
                            <span class="badge
                             <?php if($category->id == 1): ?>
                                purple
                                <?php elseif($category->id == 2): ?>
                                blue
                                <?php elseif($category->id == 3): ?>
                                red
                                <?php elseif($category->id == 4): ?>
                                yellow
                                <?php elseif($category->id == 5): ?>
                                lime
                            <?php endif; ?>
                                mr-1"><?php echo e($category->name); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>&dollar;<?php echo e($product->price); ?></p>
            <p class="card-text">
                <?php echo e(str_limit($product->description, 120, '...')); ?>

            </p>

        </div>
        <div class="card-footer">
                <span class="badge <?php echo e($product->stock > 0 ? 'badge-success' : 'badge-danger'); ?>">
                    <?php echo e($product->stock > 0 ? 'on stock' : 'not on stock'); ?>

                </span>






        </div>
    </div>
</div>
